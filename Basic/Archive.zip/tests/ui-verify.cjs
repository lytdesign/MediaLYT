// MediaLYT UI verification (development check; needs Playwright + Chromium).
// Compares the outer layout of the untouched BaseLYT V16 file against MediaLYT,
// then checks tabs, desktops, themes, breakpoints, obsolete labels and errors.
//
//   node tests/ui-verify.cjs [medialytUrl] [screenshotDir]
//
// The Media Hub engine must be running for the MediaLYT URL (default http://127.0.0.1:4717/).
const path = require('path');
const fs = require('fs');
const { chromium } = require('playwright');

const ORIGINAL = path.resolve(__dirname, '../backup/BaseLYT_Studio_Command_Center_V16.original.html');
const MEDIALYT = process.argv[2] || 'http://127.0.0.1:4717/';
const SHOTS = process.argv[3] || null;
const WIDTHS = [[1920, 1080], [1600, 1000], [1440, 900], [1280, 800], [1100, 900], [900, 1000], [600, 1100], [390, 844]];
// Same outer structure: [BaseLYT tab, MediaLYT tab]
const PAIRS = [['contributions', 'productions'], ['contributions', 'studio'], ['files', 'media'], ['settings', 'settings'], ['overview', 'overview'], ['themes', 'themes']];
const OUTER = ['.mast', '#tabs', '.stat-grid', '.stat-grid > .stat', '#workspace', '#workspace > .left-panel', '#workspace > .center-panel', '#workspace > .right-panel',
  '#workspace > .left-panel > .panel-header', '#workspace > .center-panel > .panel-header', '#workspace > .right-panel > .panel-header',
  '#missionWorkspace', '#missionWorkspace .mission-panel', '#themesWorkspace', '.desktop-footer', '#desktops'];
const STYLE_PROPS = ['paddingTop', 'paddingRight', 'paddingBottom', 'paddingLeft', 'borderTopWidth', 'borderTopColor', 'borderTopLeftRadius', 'boxShadow', 'backgroundColor', 'gap'];
const OBSOLETE = /Bug Reports?|Feature Requests?|Contribution|Contributor|Domains?\b|Cloudflare|Emails?\b|Mailbox|Studio Bridge|AI Hub|Vault Library|QuraLYT|Spaceship|Debug Inspector|Founder/;

async function open(browser, url, w, h) {
  const page = await browser.newPage({ viewport: { width: w, height: h } });
  const errors = [];
  // External CDNs (fonts, icon webfont) are blocked to keep runs deterministic;
  // the page's own inline SVG icon fallback is used instead.
  await page.route(u => !/^(http:\/\/(127\.0\.0\.1|localhost)|file:|data:|blob:)/.test(u.href), r => r.abort());
  page.on('pageerror', e => errors.push('pageerror: ' + e.message));
  page.on('console', m => { if (m.type() === 'error' && !/net::ERR_FAILED|ERR_TUNNEL/.test(m.text())) errors.push('console: ' + m.text()); });
  await page.goto(url, { waitUntil: 'domcontentloaded' });
  await page.waitForTimeout(600);
  return { page, errors };
}
async function measure(page) {
  return page.evaluate(({ OUTER, STYLE_PROPS }) => {
    const out = {};
    for (const sel of OUTER) {
      document.querySelectorAll(sel).forEach((el, i) => {
        const cs = getComputedStyle(el); if (cs.display === 'none' || el.closest('[hidden]')) return;
        const r = el.getBoundingClientRect();
        out[`${sel}#${i}`] = { x: Math.round(r.x * 10) / 10, y: Math.round(r.y * 10) / 10, w: Math.round(r.width * 10) / 10, h: Math.round(r.height * 10) / 10, ...Object.fromEntries(STYLE_PROPS.map(p => [p, cs[p]])) };
      });
    }
    return out;
  }, { OUTER, STYLE_PROPS });
}
// Fills both apps with identical placeholder content so the comparison measures
// layout rules (widths, heights, gaps, padding, borders, breakpoints), not text length.
const normalize = page => page.evaluate(() => {
  const E = id => document.getElementById(id);
  for (const id of ['left', 'middle', 'right']) { if (E(id + 'Title')) E(id + 'Title').textContent = 'Panel title'; if (E(id + 'Subtitle')) E(id + 'Subtitle').textContent = 'Panel subtitle'; }
  document.querySelectorAll('#workspace .panel-header button').forEach(b => { b.hidden = true; b.style.display = 'none'; });
  ['leftBody', 'middleBody', 'rightBody'].forEach(id => { E(id).innerHTML = '<div style="height:420px"></div>'; });
  E('rightActions').hidden = true; E('rightActions').innerHTML = '';
  document.querySelectorAll('#missionWorkspace .panel').forEach(pn => { pn.querySelector('h2').textContent = 'Panel title'; pn.querySelector('.panel-header p').textContent = 'Panel subtitle'; pn.querySelector('.mission-tag')?.remove(); pn.querySelector('.panel-body').innerHTML = '<div style="height:200px"></div>'; });
  document.querySelectorAll('.stat-grid > .stat').forEach(st => { st.querySelector('.stat-label').textContent = 'Label'; st.querySelector('.stat-num').textContent = '0'; st.querySelector('.stat-small').textContent = 'Note'; });
  document.querySelectorAll('#tabs button').forEach(b => { b.lastChild.textContent = 'Tab'; });
  const mast = { '.brand-title strong': 'Brand', '.brand-title span': 'Product', '.brand-deck': 'Tagline', '.header-title b': 'Owner', '.header-title small': 'Role', '.admin-avatar': 'A' };
  for (const [sel, text] of Object.entries(mast)) { const el = document.querySelector(sel); if (el) el.textContent = text; }
  const priv = document.querySelector('.mast .private'); if (priv) priv.lastChild.textContent = ' LABEL';
});
const tab = async (page, t) => { await page.click(`#tabs button[data-tab="${t}"]`); await page.waitForTimeout(450); };

(async () => {
  const browser = await chromium.launch();
  const report = { geometry: [], tabs: [], desktops: [], themes: [], obsolete: [], errors: [] };
  let fail = 0;

  // 1. Outer geometry, every pair at every width.
  for (const [w, h] of WIDTHS) {
    const a = await open(browser, 'file://' + ORIGINAL, w, h);
    const b = await open(browser, MEDIALYT, w, h);
    for (const [ta, tb] of PAIRS) {
      await tab(a.page, ta); await tab(b.page, tb);
      if (SHOTS && [1920, 1440, 1100, 390].includes(w)) {
        await a.page.screenshot({ path: path.join(SHOTS, `base-${ta}-${w}.png`) });
        await b.page.screenshot({ path: path.join(SHOTS, `ml-${tb}-${w}.png`) });
      }
      // As rendered (informational): differences here come from text and content length.
      const ra = await measure(a.page), rb = await measure(b.page);
      const rendered = Object.keys(rb).filter(k => ra[k] && ['x', 'y', 'w', 'h'].some(p => ra[k][p] !== rb[k][p])).length;
      // Strict: identical placeholder content in both apps.
      await normalize(a.page); await normalize(b.page); await a.page.waitForTimeout(80);
      const ma = await measure(a.page), mb = await measure(b.page);
      const diffs = [];
      for (const k of new Set([...Object.keys(ma), ...Object.keys(mb)])) {
        if (!ma[k] || !mb[k]) { diffs.push(`${k}: ${ma[k] ? 'missing in MediaLYT' : 'extra in MediaLYT'}`); continue; }
        for (const p of Object.keys(ma[k])) if (String(ma[k][p]) !== String(mb[k][p])) diffs.push(`${k}.${p}: ${ma[k][p]} → ${mb[k][p]}`);
      }
      report.geometry.push({ width: w, pair: `${ta} ↔ ${tb}`, elements: Object.keys(mb).length, diffs, renderedDiffs: rendered });
      if (diffs.length) fail++;
      // Reload so the next pair starts from real content again.
      await a.page.reload({ waitUntil: 'domcontentloaded' }); await b.page.reload({ waitUntil: 'domcontentloaded' }); await b.page.waitForTimeout(500);
    }
    report.errors.push(...b.errors.map(e => `${w}px: ${e}`));
    await a.page.close(); await b.page.close();
  }

  // 2. All nine tabs, labels and no obsolete content.
  const { page, errors } = await open(browser, MEDIALYT, 1600, 1000);
  const labels = await page.$$eval('#tabs button', bs => bs.map(b => [b.dataset.tab, b.textContent.trim()]));
  report.tabs.push({ order: labels.map(l => l[1]).join(' | ') });
  for (const [t, label] of labels) {
    await tab(page, t);
    const st = await page.evaluate(t => ({
      active: document.querySelector('#tabs button.active')?.dataset.tab,
      visibleText: document.body.innerText,
      workspace: !document.getElementById('workspace').hidden, mission: !document.getElementById('missionWorkspace').hidden, themes: !document.getElementById('themesWorkspace').hidden
    }), t);
    const bad = st.visibleText.match(OBSOLETE);
    report.tabs.push({ tab: label, active: st.active === t, view: st.mission ? 'mission' : st.themes ? 'themes' : 'three-panel' });
    if (st.active !== t) fail++;
    if (bad) { report.obsolete.push(`${label}: "${bad[0]}"`); fail++; }
  }
  // 3. Six desktops keep independent tabs.
  const expected = { 1: 'overview', 2: 'productions', 3: 'studio', 4: 'media', 5: 'publishing', 6: 'settings' };
  await page.click('#desktops button[data-desktop="1"]'); await tab(page, 'agents');
  for (const d of [2, 3, 4, 5, 6, 1]) {
    await page.click(`#desktops button[data-desktop="${d}"]`); await page.waitForTimeout(350);
    const active = await page.$eval('#tabs button.active', b => b.dataset.tab);
    const want = d === 1 ? 'agents' : expected[d];
    report.desktops.push({ desktop: d, activeTab: active, expected: want, ok: active === want });
    if (active !== want) fail++;
  }
  // 4. Themes: default Sapphire Amber, catalog intact, switching and reset.
  await tab(page, 'themes');
  const th = await page.evaluate(() => ({ current: document.getElementById('themeCurrentName').textContent, tiles: document.querySelectorAll('[data-theme-name]').length, counts: ['midCount', 'darkCount', 'lightCount'].map(id => document.getElementById(id).textContent) }));
  report.themes.push({ defaultTheme: th.current, darkTilesShown: th.tiles, counts: th.counts.join('/') });
  if (th.current !== 'Sapphire Amber') fail++;
  await page.click('[data-theme-filter="Light"]'); await page.waitForTimeout(200);
  const firstLight = await page.$eval('[data-theme-name]', el => el.dataset.themeName);
  await page.click(`[data-theme-name="${firstLight}"]`); await page.waitForTimeout(200);
  const switched = await page.$eval('#themeCurrentName', el => el.textContent);
  await page.click('#themeReset'); await page.waitForTimeout(200);
  const reset = await page.$eval('#themeCurrentName', el => el.textContent);
  report.themes.push({ switchedTo: switched, afterReset: reset, ok: switched === firstLight && reset === 'Sapphire Amber' });
  if (!(switched === firstLight && reset === 'Sapphire Amber')) fail++;
  report.errors.push(...errors);
  if (report.errors.length) fail++;
  await browser.close();

  for (const g of report.geometry) console.log(`${g.diffs.length ? 'DIFF' : 'SAME'} ${String(g.width).padStart(4)}px ${g.pair.padEnd(28)} ${g.elements} elements · as-rendered content-driven differences: ${g.renderedDiffs}${g.diffs.length ? '\n   ' + g.diffs.slice(0, 12).join('\n   ') : ''}`);
  console.log('\nTabs:', report.tabs[0].order); report.tabs.slice(1).forEach(t => console.log(`  ${t.active ? 'ok ' : 'BAD'} ${t.tab} (${t.view})`));
  console.log('Desktops:', report.desktops.map(d => `${d.desktop}:${d.activeTab}${d.ok ? '' : ' (expected ' + d.expected + ')'}`).join('  '));
  console.log('Themes:', JSON.stringify(report.themes));
  console.log('Obsolete labels:', report.obsolete.length ? report.obsolete : 'none');
  console.log('Errors:', report.errors.length ? report.errors : 'none');
  if (SHOTS) fs.writeFileSync(path.join(SHOTS, 'ui-report.json'), JSON.stringify(report, null, 1));
  console.log(fail ? `\n${fail} check(s) failed` : '\nAll UI checks passed');
  process.exit(fail ? 1 : 0);
})();
