// MediaLYT end-to-end interface walk-through (development check; needs Playwright,
// FFmpeg and a running engine). Drives the real UI against the real engine:
// New Video → brief/storyboard/script → creative approval → upload real media →
// select outputs → production approval → metadata → final approval → invalidation.
//
//   node tests/ui-e2e.cjs [medialytUrl] [screenshotDir]
const path = require('path');
const fs = require('fs');
const os = require('os');
const { execFileSync } = require('child_process');
const { chromium } = require('playwright');

const URL_ = process.argv[2] || 'http://127.0.0.1:4717/';
const SHOTS = process.argv[3] || null;
const work = fs.mkdtempSync(path.join(os.tmpdir(), 'medialyt-e2e-'));
const ff = (...a) => execFileSync('ffmpeg', ['-hide_banner', '-loglevel', 'error', '-y', ...a]);
ff('-f', 'lavfi', '-i', 'testsrc2=size=1280x720:rate=30', '-f', 'lavfi', '-i', 'sine=frequency=440:sample_rate=48000', '-t', '4', '-c:v', 'libx264', '-pix_fmt', 'yuv420p', '-c:a', 'aac', '-shortest', path.join(work, 'lamp_on.mp4'));
ff('-f', 'lavfi', '-i', 'sine=frequency=220:sample_rate=48000', '-t', '4', path.join(work, 'narration.wav'));
ff('-f', 'lavfi', '-i', 'testsrc2=size=1280x720:rate=30', '-f', 'lavfi', '-i', 'sine=frequency=330:sample_rate=48000', '-t', '4', '-c:v', 'libx264', '-pix_fmt', 'yuv420p', '-c:a', 'aac', '-shortest', path.join(work, 'final_cut.mp4'));
ff('-f', 'lavfi', '-i', 'testsrc2=size=1280x720', '-frames:v', '1', path.join(work, 'thumbnail.png'));

const step = (n, msg) => console.log(`${String(n).padStart(2)}. ${msg}`);
(async () => {
  const browser = await chromium.launch();
  const page = await browser.newPage({ viewport: { width: 1600, height: 1000 } });
  await page.route(u => !/^(http:\/\/(127\.0\.0\.1|localhost)|file:|data:|blob:)/.test(u.href), r => r.abort());
  const errors = [];
  page.on('pageerror', e => errors.push(e.message));
  page.on('dialog', d => d.accept(d.type() === 'prompt' ? 'E2E check' : undefined));
  const shot = async name => { if (SHOTS) await page.screenshot({ path: path.join(SHOTS, `e2e-${name}.png`) }); };
  const wait = ms => page.waitForTimeout(ms);
  const stateOf = cp => page.$eval(`#rightBody .ml-cp:nth-of-type(${['creative', 'production', 'final'].indexOf(cp) + 1}) .ml-check`, el => el.className.replace('ml-check', '').trim()).catch(() => 'n/a');
  const upload = async (viewLabel, buttonText, file) => {
    await page.click(`.ml-subtabs button:has-text("${viewLabel}")`); await wait(300);
    const [chooser] = await Promise.all([page.waitForEvent('filechooser'), page.click(`#middleBody button:has-text("${buttonText}")`)]);
    await chooser.setFiles(path.join(work, file)); await wait(1500);
  };

  await page.goto(URL_, { waitUntil: 'domcontentloaded' }); await wait(900);
  step(1, 'Engine status: ' + await page.textContent('#statEngine'));
  await page.click('#tabs button[data-tab="productions"]'); await wait(500);
  await page.click('#middleHeaderAction'); await wait(300);
  await page.fill('#mlNewTitle', 'LYTDesign Desk Lamp — First Look');
  await page.selectOption('#mlNewFormat', 'video');
  await page.fill('#mlNewLength', '90');
  await page.fill('#mlNewIdea', 'A calm first look at the LYTDesign desk lamp using real product footage.');
  await page.fill('#mlNewProduct', 'LYTDesign Desk Lamp');
  await page.fill('#mlNewAudience', 'Home office workers');
  await shot('01-new-video');
  await page.click('#mlNewCreate'); await wait(900);
  step(2, 'Created production; active tab: ' + await page.$eval('#tabs button.active', b => b.textContent.trim()));

  await page.fill('#mlConcept', 'Warm, focused light that disappears into your desk.');
  await page.click('#middleHeaderAction'); await wait(700);
  await page.click('.ml-subtabs button:has-text("Storyboard")'); await wait(300);
  await page.fill('#mlStoryboard', 'Scene 1 — 0:00–0:04 · clip lamp_on.mp4 · Lamp switches on.');
  await page.click('.ml-subtabs button:has-text("Script")'); await wait(300);
  await page.fill('#mlScript', '[Scene 1] Meet the LYTDesign desk lamp. Warm light, zero clutter.');
  await page.click('#middleHeaderAction'); await wait(800);
  step(3, 'Creative checkpoint: ' + await stateOf('creative'));
  await shot('02-script-ready');
  await page.click('#rightActions button.primary'); await wait(900);
  step(4, 'After approval, creative: ' + await stateOf('creative') + ' · status: ' + await page.$eval('.ml-stage-head .pill', el => el.textContent));

  await upload('Storyboard', 'Add Product Footage', 'lamp_on.mp4');
  await upload('Voice & Audio', 'Add Narration Audio', 'narration.wav');
  await page.click('#middleBody button:has-text("Use as Narration audio")'); await wait(700);
  await upload('Preview', 'Add Preview Render', 'final_cut.mp4');
  await page.click('#middleBody button:has-text("Use as Preview render")'); await wait(700);
  await shot('03-preview');
  await upload('Captions & Thumbnail', 'Add Thumbnail', 'thumbnail.png');
  await page.click('#middleBody button:has-text("Use as Selected thumbnail")'); await wait(700);
  step(5, 'Production checkpoint: ' + await stateOf('production'));
  await page.click('#rightActions button.primary'); await wait(900);
  step(6, 'After approval, production: ' + await stateOf('production'));

  await page.click('.ml-subtabs button:has-text("Final Output")'); await wait(400);
  await page.click('#middleBody button:has-text("Use as Final video")'); await wait(900);
  await shot('04-final-output');
  await page.click('#tabs button[data-tab="publishing"]'); await wait(800);
  await page.fill('#mlMetaTitle', 'LYTDesign Desk Lamp — First Look');
  await page.fill('#mlMetaDesc', 'A first look at the LYTDesign desk lamp, filmed with real product footage.');
  await page.fill('#mlMetaTags', 'LYTDesign, desk lamp, home office');
  await page.click('#middleHeaderAction'); await wait(900);
  await shot('05-publishing-ready');
  await page.click('#rightActions button.primary'); await wait(900);
  const finalLabel = await page.textContent('#rightActions button.primary');
  const uploadDisabled = await page.$eval('#rightActions button:has-text("Upload")', b => b.disabled);
  step(7, `Final approval button now: "${finalLabel.trim()}" · YouTube upload disabled: ${uploadDisabled}`);
  await shot('06-final-approved');

  await page.click('#tabs button[data-tab="studio"]'); await wait(700);
  const revStatus = await page.$eval('.ml-stage-head .pill', el => el.textContent);
  step(8, 'Production status pill: ' + await page.$eval('.ml-stage-head .pill', el => el.textContent));
  await page.click('.ml-subtabs button:has-text("Script")'); await wait(300);
  await page.fill('#mlScript', '[Scene 1] Meet the new LYTDesign desk lamp.');
  await page.click('#middleHeaderAction'); await wait(900);
  step(9, `After editing the script → creative: ${await stateOf('creative')}, production: ${await stateOf('production')}, final: ${await stateOf('final')}`);
  await shot('07-invalidated');

  await page.click('#tabs button[data-tab="media"]'); await wait(800);
  await page.click('#leftBody button[data-category="footage"]'); await wait(800);
  step(10, 'Media Library footage rows: ' + await page.$$eval('#fmFileTable .fm-file-row', r => r.length) + ' · probe shown: ' + (await page.textContent('#rightBody')).includes('1280×720'));
  await shot('08-media-library');
  await page.click('#tabs button[data-tab="overview"]'); await wait(900);
  await shot('09-overview');
  await page.click('#tabs button[data-tab="agents"]'); await wait(800);
  await shot('10-agents');
  console.log('Page errors:', errors.length ? errors : 'none');
  await browser.close();
  fs.rmSync(work, { recursive: true, force: true });
  process.exit(errors.length ? 1 : 0);
})();
