// Media Hub engine tests — node:test, no external packages.
// Runs a real engine on a random port with a temporary data folder.
import { test, before, after } from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import http from 'node:http';
import { execFileSync } from 'node:child_process';
import { createEngine } from '../engine/server.mjs';

let engine, base, dir;
const H = { 'Content-Type': 'application/json', 'X-MediaLYT': '1' };
const j = async (p, opts = {}) => {
  const r = await fetch(base + p, { ...opts, headers: { ...H, ...(opts.headers || {}) } });
  const body = r.headers.get('content-type')?.includes('json') ? await r.json() : await r.text();
  return { status: r.status, body };
};
const upload = async (category, name, data, productionId, library = 'media') => {
  const qs = new URLSearchParams({ library, category, name, ...(productionId ? { productionId } : {}) });
  return j('/api/assets?' + qs, { method: 'POST', body: data, headers: { 'Content-Type': 'application/octet-stream' } });
};
const hasFfmpeg = (() => { try { execFileSync('ffmpeg', ['-version'], { stdio: 'ignore' }); return true; } catch { return false; } })();
const waitJobs = async (pid) => { for (let i = 0; i < 100; i++) { const { body } = await j('/api/jobs?productionId=' + pid); if (!body.jobs.some(x => x.status === 'queued' || x.status === 'running')) return body.jobs; await new Promise(r => setTimeout(r, 100)); } throw new Error('jobs did not finish'); };

before(async () => {
  dir = await fs.mkdtemp(path.join(os.tmpdir(), 'medialyt-test-'));
  const app = path.join(dir, 'app.html'); await fs.writeFile(app, '<!doctype html><title>MediaLYT test</title>');
  engine = await createEngine({ port: 0, dataDir: path.join(dir, 'data'), appFile: app, quiet: true, maxUploadBytes: 5 * 1024 * 1024 });
  base = `http://127.0.0.1:${engine.port}`;
});
after(async () => { await engine.close(); await fs.rm(dir, { recursive: true, force: true }); });

test('health reports real engine, database, storage and tool state', async () => {
  const { status, body } = await j('/api/health');
  assert.equal(status, 200);
  assert.equal(body.ok, true);
  assert.equal(body.database.ok, true);
  assert.equal(body.storage.writable, true);
  assert.equal(typeof body.tools.ffmpeg.found, 'boolean');
  for (const p of ['ai', 'tts', 'youtube']) assert.equal(body.providers[p].configured, false);
  assert.ok(!JSON.stringify(body).match(/key|token|secret/i), 'health must not expose credentials');
});

test('serves the interface with a restrictive CSP', async () => {
  const r = await fetch(base + '/');
  assert.equal(r.status, 200);
  assert.match(r.headers.get('content-security-policy'), /connect-src 'self'/);
  assert.match(await r.text(), /MediaLYT test/);
});

test('rejects unknown Host headers (DNS rebinding) and cross-site writes', async () => {
  const status = await new Promise((resolve, reject) => {
    http.get({ host: '127.0.0.1', port: engine.port, path: '/api/health', headers: { Host: 'evil.example:80' } }, res => resolve(res.statusCode)).on('error', reject);
  });
  assert.equal(status, 421);
  const noHeader = await fetch(base + '/api/productions', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: '{"title":"x"}' });
  assert.equal(noHeader.status, 403);
  const crossSite = await fetch(base + '/api/productions', { method: 'POST', headers: { ...H, Origin: 'https://evil.example' }, body: '{"title":"x"}' });
  assert.equal(crossSite.status, 403);
});

test('production records persist with validation and derived status', async () => {
  const bad = await j('/api/productions', { method: 'POST', body: JSON.stringify({ title: '  ' }) });
  assert.equal(bad.status, 400);
  const { status, body: p } = await j('/api/productions', { method: 'POST', body: JSON.stringify({ title: 'Lamp first look', format: 'short', brief: { idea: 'Show the lamp', targetLengthSec: 45 } }) });
  assert.equal(status, 201);
  assert.equal(p.status, 'draft');
  assert.equal(p.format, 'short');
  assert.equal(p.brief.targetLengthSec, 45);
  const list = await j('/api/productions');
  assert.ok(list.body.productions.some(x => x.id === p.id));
  const longTitle = await j('/api/productions/' + p.id, { method: 'PATCH', body: JSON.stringify({ metadata: { title: 'x'.repeat(101) } }) });
  assert.equal(longTitle.status, 400);
});

test('agent execution is refused honestly, without creating jobs', async () => {
  const { body: p } = await j('/api/productions', { method: 'POST', body: JSON.stringify({ title: 'Agent refusal' }) });
  const r = await j(`/api/productions/${p.id}/agents/director/run`, { method: 'POST', body: '{}' });
  assert.equal(r.status, 501);
  const jobs = await j('/api/jobs?productionId=' + p.id);
  assert.equal(jobs.body.jobs.length, 0);
  const agents = await j('/api/agents');
  assert.equal(agents.body.agents.length, 6);
  assert.ok(agents.body.agents.every(a => a.implemented === false && a.canRun === false));
});

test('uploads are fingerprinted, range-served and type-checked', async () => {
  const data = Buffer.from('1\n00:00:00,000 --> 00:00:01,000\nHello LYTDesign\n');
  const wrongType = await upload('captions', 'notes.exe', data);
  assert.equal(wrongType.status, 415);
  const traversal = await upload('captions', '../../etc/passwd.srt', data);
  assert.equal(traversal.status, 201);
  assert.ok(!traversal.body.asset.storedPath.includes('..'));
  const { status, body } = await upload('captions', 'intro.srt', data);
  assert.equal(status, 201);
  const crypto = await import('node:crypto');
  assert.equal(body.asset.sha256, crypto.createHash('sha256').update(data).digest('hex'));
  const r = await fetch(`${base}/api/assets/${body.asset.id}/content`, { headers: { Range: 'bytes=0-4' } });
  assert.equal(r.status, 206);
  assert.equal(await r.text(), data.subarray(0, 5).toString());
  const tooBig = await upload('captions', 'big.srt', Buffer.alloc(6 * 1024 * 1024, 65));
  assert.equal(tooBig.status, 413);
  const del = await j('/api/assets/' + body.asset.id, { method: 'DELETE' });
  assert.equal(del.status, 200);
});

test('three approval checkpoints with fingerprints and invalidation', { skip: !hasFfmpeg && 'ffmpeg not installed' }, async () => {
  const { body: p } = await j('/api/productions', { method: 'POST', body: JSON.stringify({ title: 'Approval flow', format: 'video' }) });
  const id = p.id;
  // Creative: incomplete → ready → approved
  let v = (await j('/api/productions/' + id)).body;
  assert.equal(v.approvals.creative.state, 'incomplete');
  const early = await j(`/api/productions/${id}/approvals/creative`, { method: 'POST', body: JSON.stringify({ fingerprint: 'x' }) });
  assert.equal(early.status, 409);
  v = (await j('/api/productions/' + id, { method: 'PATCH', body: JSON.stringify({ brief: { concept: 'Warm light for focused work' }, storyboard: 'Scene 1 — lamp on', script: 'Meet the lamp.' }) })).body;
  assert.equal(v.approvals.creative.state, 'ready');
  assert.equal(v.status, 'review');
  const stale = await j(`/api/productions/${id}/approvals/creative`, { method: 'POST', body: JSON.stringify({ fingerprint: '0'.repeat(64) }) });
  assert.equal(stale.status, 409, 'approval of content the user did not review is refused');
  v = (await j(`/api/productions/${id}/approvals/creative`, { method: 'POST', body: JSON.stringify({ fingerprint: v.approvals.creative.fingerprint, note: 'ok' }) })).body;
  assert.equal(v.approvals.creative.state, 'approved');

  // Real media made with FFmpeg
  const work = path.join(dir, 'media'); await fs.mkdir(work, { recursive: true });
  const ff = (...a) => execFileSync('ffmpeg', ['-hide_banner', '-loglevel', 'error', '-y', ...a]);
  ff('-f', 'lavfi', '-i', 'testsrc2=size=640x360:rate=25', '-f', 'lavfi', '-i', 'sine=frequency=440:sample_rate=48000', '-t', '2', '-c:v', 'libx264', '-pix_fmt', 'yuv420p', '-c:a', 'aac', '-shortest', path.join(work, 'render.mp4'));
  ff('-f', 'lavfi', '-i', 'sine=frequency=220:sample_rate=48000', '-t', '2', path.join(work, 'voice.wav'));
  ff('-f', 'lavfi', '-i', 'testsrc2=size=1280x720', '-frames:v', '1', path.join(work, 'thumb.png'));
  const up = async (cat, file) => (await upload(cat, file, await fs.readFile(path.join(work, file)), id)).body.asset;
  const render = await up('renders', 'render.mp4'), voice = await up('audio', 'voice.wav'), thumb = await up('thumbnails', 'thumb.png');
  const jobs = await waitJobs(id);
  assert.ok(jobs.filter(x => x.type === 'media.probe').every(x => x.status === 'succeeded'), 'probe jobs succeed');
  const probed = (await j('/api/assets/' + render.id)).body.probe;
  assert.equal(probed.video.width, 640);
  assert.ok(Math.abs(probed.durationSec - 2) < 0.2);

  // Wrong-category role assignment is refused
  const wrongRole = await j('/api/productions/' + id, { method: 'PATCH', body: JSON.stringify({ roles: { narration: render.id } }) });
  assert.equal(wrongRole.status, 400);
  v = (await j('/api/productions/' + id, { method: 'PATCH', body: JSON.stringify({ roles: { narration: voice.id, preview: render.id, thumbnail: thumb.id } }) })).body;
  assert.equal(v.approvals.production.state, 'ready');
  v = (await j(`/api/productions/${id}/approvals/production`, { method: 'POST', body: JSON.stringify({ fingerprint: v.approvals.production.fingerprint }) })).body;
  assert.equal(v.approvals.production.state, 'approved');

  // Final
  v = (await j('/api/productions/' + id, { method: 'PATCH', body: JSON.stringify({ roles: { final: render.id }, metadata: { title: 'LYTDesign lamp', description: 'First look.', tags: ['lamp'], privacy: 'private' } }) })).body;
  assert.equal(v.approvals.final.state, 'ready');
  v = (await j(`/api/productions/${id}/approvals/final`, { method: 'POST', body: JSON.stringify({ fingerprint: v.approvals.final.fingerprint }) })).body;
  assert.equal(v.approvals.final.state, 'approved');
  assert.equal(v.status, 'approved');

  // Deleting an asset that is in use is refused
  assert.equal((await j('/api/assets/' + render.id, { method: 'DELETE' })).status, 409);

  // Changing metadata invalidates only the final approval
  v = (await j('/api/productions/' + id, { method: 'PATCH', body: JSON.stringify({ metadata: { title: 'LYTDesign lamp v2', description: 'First look.', tags: ['lamp'] } }) })).body;
  assert.equal(v.approvals.final.state, 'invalidated');
  assert.equal(v.approvals.production.state, 'approved');
  assert.equal(v.status, 'review');

  // Modifying the approved thumbnail file on disk invalidates production and therefore final
  const thumbPath = path.join(engine.dataDir, thumb.storedPath);
  await fs.appendFile(thumbPath, Buffer.from([0]));
  v = (await j('/api/productions/' + id)).body;
  assert.equal(v.approvals.production.state, 'invalidated');
  assert.equal(v.approvals.final.state, 'invalidated');

  // Editing the script invalidates the creative checkpoint and everything after it
  v = (await j('/api/productions/' + id, { method: 'PATCH', body: JSON.stringify({ script: 'Meet the new lamp.' }) })).body;
  assert.equal(v.approvals.creative.state, 'invalidated');

  // Request changes withdraws an approval and is logged
  v = (await j(`/api/productions/${id}/approvals/production`, { method: 'DELETE', body: JSON.stringify({ reason: 'Re-record narration' }) })).body;
  assert.equal(v.approvals.production.approved, false);
  const events = (await j(`/api/productions/${id}/events`)).body.events.map(e => e.kind);
  for (const k of ['approval.granted', 'approval.invalidated', 'approval.changes-requested', 'asset.added']) assert.ok(events.includes(k), 'logged ' + k);
});

test('records survive an engine restart; interrupted jobs are failed honestly', async () => {
  const { body: p } = await j('/api/productions', { method: 'POST', body: JSON.stringify({ title: 'Persistence check' }) });
  engine.db.createJob({ productionId: p.id, type: 'render.final', agent: 'editor' });
  const dataDir = engine.dataDir; const app = path.join(dir, 'app.html');
  await engine.close();
  engine = await createEngine({ port: 0, dataDir, appFile: app, quiet: true });
  base = `http://127.0.0.1:${engine.port}`;
  const v = (await j('/api/productions/' + p.id)).body;
  assert.equal(v.title, 'Persistence check');
  assert.equal(v.jobs[0].status, 'failed');
  assert.match(v.jobs[0].error, /Engine stopped/);
  assert.equal(v.status, 'failed');
});

test('brand library notes', async () => {
  const bad = await j('/api/brand/notes', { method: 'POST', body: JSON.stringify({ kind: 'x', title: 'a' }) });
  assert.equal(bad.status, 400);
  const { status, body } = await j('/api/brand/notes', { method: 'POST', body: JSON.stringify({ kind: 'product', title: 'Desk lamp', body: 'Warm 2700K LED' }) });
  assert.equal(status, 201);
  const upd = await j('/api/brand/notes/' + body.id, { method: 'PATCH', body: JSON.stringify({ kind: 'product', title: 'Desk lamp', body: 'Warm 2700–4000K LED' }) });
  assert.equal(upd.body.body, 'Warm 2700–4000K LED');
  assert.equal((await j('/api/brand/notes/' + body.id, { method: 'DELETE' })).status, 200);
});
