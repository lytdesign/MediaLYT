#!/usr/bin/env bash
# MediaLYT host check — READ-ONLY. Installs nothing, changes nothing.
# Run on the Manjaro laptop:  bash scripts/check-host.sh
set -u
ok()   { printf '  \033[32m✓\033[0m %-14s %s\n' "$1" "$2"; }
warn() { printf '  \033[33m!\033[0m %-14s %s\n' "$1" "$2"; }
bad()  { printf '  \033[31m✕\033[0m %-14s %s\n' "$1" "$2"; }
ver()  { "$@" 2>&1 | head -n1; }

echo "MediaLYT host check — $(date -Iseconds)"
echo "System"
ok "OS" "$( (. /etc/os-release 2>/dev/null && echo "$PRETTY_NAME") || uname -s) · kernel $(uname -r) · $(uname -m)"
ok "CPU" "$(nproc) threads · $(grep -m1 'model name' /proc/cpuinfo 2>/dev/null | cut -d: -f2 | sed 's/^ //')"
ok "Memory" "$(free -h 2>/dev/null | awk '/^Mem:/{print $2" total, "$7" available"}')"
ok "Disk (here)" "$(df -h . 2>/dev/null | awk 'NR==2{print $4" free of "$2}')"
if command -v nvidia-smi >/dev/null; then ok "GPU" "$(nvidia-smi --query-gpu=name --format=csv,noheader 2>/dev/null | head -n1)"; else
  g=$(lspci 2>/dev/null | grep -iE 'vga|3d' | head -n1 | cut -d: -f3-); [ -n "$g" ] && ok "GPU" "$g (FFmpeg uses CPU encoding in V1)" || warn "GPU" "not detected (not required)"; fi

echo "Required for MediaLYT V1"
if command -v node >/dev/null; then
  v=$(node -v); maj=${v#v}; maj=${maj%%.*}; min=$(echo "$v" | cut -d. -f2)
  if [ "$maj" -gt 22 ] || { [ "$maj" -eq 22 ] && [ "$min" -ge 13 ]; }; then ok "Node.js" "$v"; else bad "Node.js" "$v — need ≥ 22.13 for built-in node:sqlite"; fi
  if node -e "require('node:sqlite')" 2>/dev/null; then ok "node:sqlite" "available"; else bad "node:sqlite" "not available in this Node.js"; fi
else bad "Node.js" "not found (Manjaro: pacman -S nodejs npm — not run by this script)"; fi
if command -v ffmpeg >/dev/null; then
  ok "FFmpeg" "$(ver ffmpeg -hide_banner -version | awk '{print $3}')"
  enc=$(ffmpeg -hide_banner -encoders 2>/dev/null); flt=$(ffmpeg -hide_banner -filters 2>/dev/null)
  for e in libx264 aac libopus libx265; do echo "$enc" | grep -qw "$e" && ok "  encoder" "$e" || warn "  encoder" "$e missing"; done
  for f in subtitles drawtext xfade loudnorm; do echo "$flt" | grep -qw "$f" && ok "  filter" "$f" || warn "  filter" "$f missing"; done
else bad "FFmpeg" "not found (Manjaro: pacman -S ffmpeg — not run by this script)"; fi
command -v ffprobe >/dev/null && ok "ffprobe" "$(ver ffprobe -hide_banner -version | awk '{print $3}')" || bad "ffprobe" "not found (ships with ffmpeg)"

echo "Optional / later phases"
for t in python3 git sqlite3 magick convert whisper whisper-cli yt-dlp docker; do
  if command -v "$t" >/dev/null; then ok "$t" "$(ver "$t" --version 2>/dev/null || echo present)"; else warn "$t" "not found"; fi
done

echo "Network / ports"
if command -v ss >/dev/null; then
  if ss -ltn 2>/dev/null | grep -q ':4717 '; then warn "Port 4717" "already in use (set MEDIALYT_PORT)"; else ok "Port 4717" "free"; fi
elif (exec 3<>/dev/tcp/127.0.0.1/4717) 2>/dev/null; then warn "Port 4717" "already in use (set MEDIALYT_PORT)"
else ok "Port 4717" "free"; fi
echo "Done. Nothing was installed or modified."
