// MediaLYT Media Hub — SQLite persistence (node:sqlite, no external packages).
import { DatabaseSync } from 'node:sqlite';
import { randomUUID } from 'node:crypto';

const SCHEMA = `
PRAGMA journal_mode = WAL;
PRAGMA foreign_keys = ON;
CREATE TABLE IF NOT EXISTS meta (key TEXT PRIMARY KEY, value TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS productions (
  id TEXT PRIMARY KEY,
  title TEXT NOT NULL,
  format TEXT NOT NULL CHECK (format IN ('video','short')),
  brief TEXT NOT NULL DEFAULT '{}',
  storyboard TEXT NOT NULL DEFAULT '',
  script TEXT NOT NULL DEFAULT '',
  captions TEXT NOT NULL DEFAULT '',
  metadata TEXT NOT NULL DEFAULT '{}',
  roles TEXT NOT NULL DEFAULT '{}',
  archived INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS assets (
  id TEXT PRIMARY KEY,
  library TEXT NOT NULL CHECK (library IN ('media','brand')),
  category TEXT NOT NULL,
  production_id TEXT REFERENCES productions(id) ON DELETE SET NULL,
  original_name TEXT NOT NULL,
  stored_path TEXT NOT NULL,
  mime TEXT NOT NULL,
  size INTEGER NOT NULL,
  sha256 TEXT NOT NULL,
  probe TEXT,
  created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS jobs (
  id TEXT PRIMARY KEY,
  production_id TEXT REFERENCES productions(id) ON DELETE CASCADE,
  asset_id TEXT REFERENCES assets(id) ON DELETE CASCADE,
  type TEXT NOT NULL,
  agent TEXT,
  status TEXT NOT NULL CHECK (status IN ('queued','running','succeeded','failed','cancelled')),
  progress REAL,
  message TEXT NOT NULL DEFAULT '',
  error TEXT,
  created_at TEXT NOT NULL,
  started_at TEXT,
  finished_at TEXT
);
CREATE TABLE IF NOT EXISTS approvals (
  production_id TEXT NOT NULL REFERENCES productions(id) ON DELETE CASCADE,
  checkpoint TEXT NOT NULL CHECK (checkpoint IN ('creative','production','final')),
  fingerprint TEXT NOT NULL,
  note TEXT NOT NULL DEFAULT '',
  approved_at TEXT NOT NULL,
  PRIMARY KEY (production_id, checkpoint)
);
CREATE TABLE IF NOT EXISTS events (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  production_id TEXT,
  level TEXT NOT NULL CHECK (level IN ('info','warn','error')),
  kind TEXT NOT NULL,
  message TEXT NOT NULL,
  data TEXT,
  created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS brand_notes (
  id TEXT PRIMARY KEY,
  kind TEXT NOT NULL CHECK (kind IN ('product','template','guideline')),
  title TEXT NOT NULL,
  body TEXT NOT NULL DEFAULT '',
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_assets_lib ON assets(library, category);
CREATE INDEX IF NOT EXISTS idx_assets_prod ON assets(production_id);
CREATE INDEX IF NOT EXISTS idx_jobs_prod ON jobs(production_id);
CREATE INDEX IF NOT EXISTS idx_events_prod ON events(production_id, id);
`;

const now = () => new Date().toISOString();
const parse = (s, fallback) => { try { return JSON.parse(s); } catch { return fallback; } };

export function openDatabase(file) {
  const db = new DatabaseSync(file);
  db.exec(SCHEMA);
  db.prepare("INSERT OR IGNORE INTO meta(key,value) VALUES ('schema_version','1')").run();

  const rowToProduction = r => r && ({
    id: r.id, title: r.title, format: r.format,
    brief: parse(r.brief, {}), storyboard: r.storyboard, script: r.script, captions: r.captions,
    metadata: parse(r.metadata, {}), roles: parse(r.roles, {}),
    archived: !!r.archived, createdAt: r.created_at, updatedAt: r.updated_at
  });
  const rowToAsset = r => r && ({
    id: r.id, library: r.library, category: r.category, productionId: r.production_id,
    name: r.original_name, storedPath: r.stored_path, mime: r.mime, size: r.size,
    sha256: r.sha256, probe: r.probe ? parse(r.probe, null) : null, createdAt: r.created_at
  });
  const rowToJob = r => r && ({
    id: r.id, productionId: r.production_id, assetId: r.asset_id, type: r.type, agent: r.agent,
    status: r.status, progress: r.progress, message: r.message, error: r.error,
    createdAt: r.created_at, startedAt: r.started_at, finishedAt: r.finished_at
  });
  const rowToEvent = r => ({ id: r.id, productionId: r.production_id, level: r.level, kind: r.kind,
    message: r.message, data: r.data ? parse(r.data, null) : null, createdAt: r.created_at });

  const api = {
    raw: db,
    close: () => db.close(),
    schemaVersion: () => db.prepare("SELECT value FROM meta WHERE key='schema_version'").get()?.value,

    logEvent(productionId, level, kind, message, data) {
      db.prepare('INSERT INTO events(production_id,level,kind,message,data,created_at) VALUES (?,?,?,?,?,?)')
        .run(productionId ?? null, level, kind, message, data === undefined ? null : JSON.stringify(data), now());
    },
    listEvents({ productionId, limit = 100 } = {}) {
      const lim = Math.max(1, Math.min(500, Number(limit) || 100));
      const rows = productionId
        ? db.prepare('SELECT * FROM events WHERE production_id=? ORDER BY id DESC LIMIT ?').all(productionId, lim)
        : db.prepare('SELECT * FROM events ORDER BY id DESC LIMIT ?').all(lim);
      return rows.map(rowToEvent);
    },

    createProduction({ title, format }) {
      const id = 'prd_' + randomUUID().replace(/-/g, '').slice(0, 16);
      const t = now();
      db.prepare('INSERT INTO productions(id,title,format,created_at,updated_at) VALUES (?,?,?,?,?)').run(id, title, format, t, t);
      return api.getProduction(id);
    },
    getProduction(id) { return rowToProduction(db.prepare('SELECT * FROM productions WHERE id=?').get(id)); },
    listProductions({ includeArchived = false } = {}) {
      const sql = includeArchived ? 'SELECT * FROM productions ORDER BY updated_at DESC' : 'SELECT * FROM productions WHERE archived=0 ORDER BY updated_at DESC';
      return db.prepare(sql).all().map(rowToProduction);
    },
    updateProduction(id, patch) {
      const cur = api.getProduction(id);
      if (!cur) return null;
      const next = { ...cur, ...patch };
      db.prepare(`UPDATE productions SET title=?,format=?,brief=?,storyboard=?,script=?,captions=?,metadata=?,roles=?,archived=?,updated_at=? WHERE id=?`)
        .run(next.title, next.format, JSON.stringify(next.brief), next.storyboard, next.script, next.captions,
          JSON.stringify(next.metadata), JSON.stringify(next.roles), next.archived ? 1 : 0, now(), id);
      return api.getProduction(id);
    },
    deleteProduction(id) { return db.prepare('DELETE FROM productions WHERE id=?').run(id).changes > 0; },

    insertAsset(a) {
      db.prepare('INSERT INTO assets(id,library,category,production_id,original_name,stored_path,mime,size,sha256,created_at) VALUES (?,?,?,?,?,?,?,?,?,?)')
        .run(a.id, a.library, a.category, a.productionId ?? null, a.name, a.storedPath, a.mime, a.size, a.sha256, now());
      return api.getAsset(a.id);
    },
    getAsset(id) { return rowToAsset(db.prepare('SELECT * FROM assets WHERE id=?').get(id)); },
    listAssets({ library, category, productionId } = {}) {
      const where = [], args = [];
      if (library) { where.push('library=?'); args.push(library); }
      if (category) { where.push('category=?'); args.push(category); }
      if (productionId) { where.push('production_id=?'); args.push(productionId); }
      const sql = 'SELECT * FROM assets' + (where.length ? ' WHERE ' + where.join(' AND ') : '') + ' ORDER BY created_at DESC';
      return db.prepare(sql).all(...args).map(rowToAsset);
    },
    countAssets() {
      return db.prepare('SELECT library, category, COUNT(*) AS n, COALESCE(SUM(size),0) AS bytes FROM assets GROUP BY library, category').all();
    },
    setAssetProbe(id, probe) { db.prepare('UPDATE assets SET probe=? WHERE id=?').run(JSON.stringify(probe), id); },
    deleteAsset(id) { return db.prepare('DELETE FROM assets WHERE id=?').run(id).changes > 0; },

    createJob({ productionId, assetId, type, agent, message = '' }) {
      const id = 'job_' + randomUUID().replace(/-/g, '').slice(0, 16);
      db.prepare("INSERT INTO jobs(id,production_id,asset_id,type,agent,status,message,created_at) VALUES (?,?,?,?,?,'queued',?,?)")
        .run(id, productionId ?? null, assetId ?? null, type, agent ?? null, message, now());
      return api.getJob(id);
    },
    getJob(id) { return rowToJob(db.prepare('SELECT * FROM jobs WHERE id=?').get(id)); },
    listJobs({ productionId, status, limit = 100 } = {}) {
      const where = [], args = [];
      if (productionId) { where.push('production_id=?'); args.push(productionId); }
      if (status) { where.push('status=?'); args.push(status); }
      args.push(Math.max(1, Math.min(500, Number(limit) || 100)));
      return db.prepare('SELECT * FROM jobs' + (where.length ? ' WHERE ' + where.join(' AND ') : '') + ' ORDER BY created_at DESC LIMIT ?').all(...args).map(rowToJob);
    },
    updateJob(id, fields) {
      const cur = api.getJob(id); if (!cur) return null;
      const n = { ...cur, ...fields };
      db.prepare('UPDATE jobs SET status=?,progress=?,message=?,error=?,started_at=?,finished_at=? WHERE id=?')
        .run(n.status, n.progress ?? null, n.message ?? '', n.error ?? null, n.startedAt ?? null, n.finishedAt ?? null, id);
      return api.getJob(id);
    },
    // Jobs left 'running' by a crashed engine are failed honestly on restart.
    failInterruptedJobs() {
      return db.prepare("UPDATE jobs SET status='failed', error='Engine stopped before this job finished.', finished_at=? WHERE status IN ('queued','running')").run(now()).changes;
    },

    getApprovals(productionId) {
      return db.prepare('SELECT * FROM approvals WHERE production_id=?').all(productionId)
        .map(r => ({ checkpoint: r.checkpoint, fingerprint: r.fingerprint, note: r.note, approvedAt: r.approved_at }));
    },
    setApproval(productionId, checkpoint, fingerprint, note) {
      db.prepare('INSERT OR REPLACE INTO approvals(production_id,checkpoint,fingerprint,note,approved_at) VALUES (?,?,?,?,?)')
        .run(productionId, checkpoint, fingerprint, note || '', now());
    },
    clearApproval(productionId, checkpoint) {
      return db.prepare('DELETE FROM approvals WHERE production_id=? AND checkpoint=?').run(productionId, checkpoint).changes > 0;
    },

    listBrandNotes() {
      return db.prepare('SELECT * FROM brand_notes ORDER BY updated_at DESC').all()
        .map(r => ({ id: r.id, kind: r.kind, title: r.title, body: r.body, createdAt: r.created_at, updatedAt: r.updated_at }));
    },
    createBrandNote({ kind, title, body }) {
      const id = 'brn_' + randomUUID().replace(/-/g, '').slice(0, 16); const t = now();
      db.prepare('INSERT INTO brand_notes(id,kind,title,body,created_at,updated_at) VALUES (?,?,?,?,?,?)').run(id, kind, title, body || '', t, t);
      return api.listBrandNotes().find(n => n.id === id);
    },
    updateBrandNote(id, { kind, title, body }) {
      const r = db.prepare('UPDATE brand_notes SET kind=?,title=?,body=?,updated_at=? WHERE id=?').run(kind, title, body || '', now(), id);
      return r.changes ? api.listBrandNotes().find(n => n.id === id) : null;
    },
    deleteBrandNote(id) { return db.prepare('DELETE FROM brand_notes WHERE id=?').run(id).changes > 0; }
  };
  return api;
}
