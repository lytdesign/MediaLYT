// MediaLYT Media Hub — local file storage, hashing and tool detection.
import { createHash, randomUUID } from 'node:crypto';
import { createReadStream, createWriteStream } from 'node:fs';
import fs from 'node:fs/promises';
import path from 'node:path';
import { execFile } from 'node:child_process';
import { pipeline } from 'node:stream/promises';
import { Transform } from 'node:stream';

export const LIBRARIES = {
  media: {
    footage: { label: 'Source Footage', ext: ['mp4', 'mov', 'mkv', 'webm', 'm4v', 'avi'] },
    audio: { label: 'Audio & Narration', ext: ['wav', 'mp3', 'm4a', 'aac', 'flac', 'ogg', 'opus'] },
    captions: { label: 'Captions', ext: ['srt', 'vtt', 'ass'] },
    thumbnails: { label: 'Thumbnails', ext: ['png', 'jpg', 'jpeg', 'webp'] },
    renders: { label: 'Rendered Videos', ext: ['mp4', 'mov', 'webm', 'mkv'] }
  },
  brand: {
    logos: { label: 'Logos', ext: ['png', 'svg', 'jpg', 'jpeg', 'webp'] },
    visual: { label: 'Visual Assets', ext: ['png', 'jpg', 'jpeg', 'webp', 'svg', 'mp4', 'mov', 'webm'] },
    audio: { label: 'Brand Audio', ext: ['wav', 'mp3', 'm4a', 'aac', 'flac', 'ogg'] },
    fonts: { label: 'Fonts', ext: ['ttf', 'otf', 'woff', 'woff2'] },
    documents: { label: 'Product Documents', ext: ['pdf', 'txt', 'md'] }
  }
};

const MIME = {
  mp4: 'video/mp4', m4v: 'video/mp4', mov: 'video/quicktime', mkv: 'video/x-matroska', webm: 'video/webm', avi: 'video/x-msvideo',
  wav: 'audio/wav', mp3: 'audio/mpeg', m4a: 'audio/mp4', aac: 'audio/aac', flac: 'audio/flac', ogg: 'audio/ogg', opus: 'audio/ogg',
  srt: 'application/x-subrip', vtt: 'text/vtt', ass: 'text/plain',
  png: 'image/png', jpg: 'image/jpeg', jpeg: 'image/jpeg', webp: 'image/webp', svg: 'image/svg+xml',
  ttf: 'font/ttf', otf: 'font/otf', woff: 'font/woff', woff2: 'font/woff2', pdf: 'application/pdf', txt: 'text/plain', md: 'text/markdown'
};

export const extOf = name => (String(name).match(/\.([a-z0-9]{1,8})$/i)?.[1] || '').toLowerCase();
export const mimeOf = name => MIME[extOf(name)] || 'application/octet-stream';

// Keeps letters, digits, dot, dash and underscore; never allows path separators or traversal.
export function safeFileName(name) {
  const base = path.basename(String(name || '')).normalize('NFKC');
  const cleaned = base.replace(/[^\p{L}\p{N}._ -]+/gu, '_').replace(/\s+/g, '_').replace(/^\.+/, '').slice(0, 120);
  return cleaned || 'file';
}

export async function ensureStorage(root) {
  for (const [lib, cats] of Object.entries(LIBRARIES))
    for (const cat of Object.keys(cats)) await fs.mkdir(path.join(root, 'library', lib, cat), { recursive: true });
  await fs.mkdir(path.join(root, 'tmp'), { recursive: true });
}

// Streams the request body to disk while hashing it; enforces a byte limit.
export async function storeUpload(root, { library, category, name, source, maxBytes }) {
  const id = 'ast_' + randomUUID().replace(/-/g, '').slice(0, 16);
  const fileName = `${id}-${safeFileName(name)}`;
  const rel = path.posix.join('library', library, category, fileName);
  const tmp = path.join(root, 'tmp', id + '.part');
  const hash = createHash('sha256');
  let size = 0;
  const meter = new Transform({
    transform(chunk, _enc, cb) {
      size += chunk.length;
      if (size > maxBytes) return cb(Object.assign(new Error(`Upload exceeds the ${maxBytes} byte limit.`), { status: 413 }));
      hash.update(chunk); cb(null, chunk);
    }
  });
  try {
    await pipeline(source, meter, createWriteStream(tmp, { flags: 'wx' }));
    if (size === 0) throw Object.assign(new Error('The uploaded file is empty.'), { status: 400 });
    await fs.rename(tmp, path.join(root, rel));
  } catch (err) {
    await fs.rm(tmp, { force: true });
    throw err;
  }
  return { id, storedPath: rel, size, sha256: hash.digest('hex'), mime: mimeOf(name) };
}

// Re-hashes a stored file, cached by size + mtime so unchanged files are not re-read.
const hashCache = new Map();
export async function currentFileHash(root, rel) {
  const abs = resolveStored(root, rel);
  let st;
  try { st = await fs.stat(abs); } catch { return null; }
  const key = `${abs}:${st.size}:${st.mtimeMs}`;
  if (hashCache.has(key)) return hashCache.get(key);
  const hash = createHash('sha256');
  await pipeline(createReadStream(abs), hash);
  const digest = hash.digest('hex');
  hashCache.set(key, digest);
  return digest;
}

export function resolveStored(root, rel) {
  const abs = path.resolve(root, rel);
  if (!abs.startsWith(path.resolve(root) + path.sep)) throw Object.assign(new Error('Invalid stored path.'), { status: 400 });
  return abs;
}

const run = (cmd, args, timeout = 15000) => new Promise(resolve => {
  execFile(cmd, args, { timeout, maxBuffer: 8 * 1024 * 1024 }, (err, stdout, stderr) => resolve({ err, stdout: String(stdout), stderr: String(stderr) }));
});

export async function detectTools() {
  const probe = async (cmd) => {
    const r = await run(cmd, ['-hide_banner', '-version'], 8000);
    if (r.err) return { found: false, error: r.err.code === 'ENOENT' ? 'Not found on PATH' : String(r.err.message).slice(0, 200) };
    const first = r.stdout.split('\n')[0] || '';
    return { found: true, version: first.match(/version\s+(\S+)/)?.[1] || first.slice(0, 80) };
  };
  const [ffmpeg, ffprobe] = await Promise.all([probe('ffmpeg'), probe('ffprobe')]);
  if (ffmpeg.found) {
    const enc = await run('ffmpeg', ['-hide_banner', '-encoders'], 8000);
    const flt = await run('ffmpeg', ['-hide_banner', '-filters'], 8000);
    ffmpeg.encoders = ['libx264', 'libx265', 'aac', 'libopus', 'libmp3lame'].filter(e => new RegExp(`\\s${e}\\s`).test(enc.stdout));
    ffmpeg.filters = ['subtitles', 'ass', 'drawtext', 'xfade', 'loudnorm', 'zoompan'].filter(f => new RegExp(`\\s${f}\\s`).test(flt.stdout));
  }
  return { ffmpeg, ffprobe, checkedAt: new Date().toISOString() };
}

export async function ffprobeFile(absPath) {
  const r = await run('ffprobe', ['-v', 'error', '-print_format', 'json', '-show_format', '-show_streams', absPath], 60000);
  if (r.err) throw new Error((r.stderr || r.err.message).trim().slice(0, 500) || 'ffprobe failed');
  const j = JSON.parse(r.stdout);
  const v = (j.streams || []).find(s => s.codec_type === 'video');
  const a = (j.streams || []).find(s => s.codec_type === 'audio');
  const fps = v?.avg_frame_rate && v.avg_frame_rate !== '0/0' ? (([n, d]) => +(n / d).toFixed(3))(v.avg_frame_rate.split('/').map(Number)) : null;
  return {
    durationSec: j.format?.duration ? +Number(j.format.duration).toFixed(3) : null,
    container: j.format?.format_name || null,
    bitRate: j.format?.bit_rate ? Number(j.format.bit_rate) : null,
    video: v ? { codec: v.codec_name, width: v.width, height: v.height, fps, pixFmt: v.pix_fmt || null } : null,
    audio: a ? { codec: a.codec_name, sampleRate: a.sample_rate ? Number(a.sample_rate) : null, channels: a.channels ?? null } : null
  };
}

export async function storageInfo(root) {
  const info = { root, writable: false, freeBytes: null };
  try { await fs.access(root, fs.constants.W_OK); info.writable = true; } catch {}
  try { const s = await fs.statfs(root); info.freeBytes = s.bavail * s.bsize; } catch {}
  return info;
}
