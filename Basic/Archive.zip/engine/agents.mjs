// MediaLYT Media Hub — the six production roles.
// V1 defines the roles, their contracts and their real prerequisites. No agent
// runner is implemented yet, so every role reports `implemented: false` and the
// engine refuses to start agent jobs instead of simulating them.
export const AGENTS = [
  {
    id: 'director', name: 'Director', stage: 'Planning',
    responsibility: 'Turns the video idea and real product footage into a concept, research notes and a storyboard mapped to available clips.',
    inputs: ['Brief (idea, product, audience, format)', 'Source footage list with probe metadata', 'Brand Library notes'],
    outputs: ['Concept', 'Storyboard (scenes → clips)'],
    requires: ['ai'], checkpoint: 'creative'
  },
  {
    id: 'scriptwriter', name: 'Scriptwriter', stage: 'Script',
    responsibility: 'Writes narration and scene descriptions that match the approved storyboard, target length and LYTDesign voice.',
    inputs: ['Concept', 'Storyboard', 'Brand guidelines'],
    outputs: ['Narration script', 'Scene descriptions'],
    requires: ['ai'], checkpoint: 'creative'
  },
  {
    id: 'voice', name: 'Voice Artist', stage: 'Voice',
    responsibility: 'Produces narration audio from the approved script through the selected text-to-speech provider.',
    inputs: ['Approved script', 'Voice selection'],
    outputs: ['Narration audio file'],
    requires: ['tts'], checkpoint: 'production'
  },
  {
    id: 'editor', name: 'Video Editor', stage: 'Editing',
    responsibility: 'Plans cuts, transitions and captions as an edit decision list, then renders preview and final MP4 files deterministically with FFmpeg.',
    inputs: ['Source footage', 'Narration audio', 'Storyboard', 'Captions'],
    outputs: ['Edit plan', 'Preview render', 'Final render', 'Caption file'],
    requires: ['ffmpeg', 'ai'], checkpoint: 'production'
  },
  {
    id: 'thumbnail', name: 'Thumbnail Designer', stage: 'Thumbnail',
    responsibility: 'Creates thumbnail concepts from real frames, brand logos and title text.',
    inputs: ['Source footage frames', 'Brand logos and fonts', 'Video title'],
    outputs: ['Thumbnail candidates'],
    requires: ['ffmpeg', 'ai'], checkpoint: 'production'
  },
  {
    id: 'publisher', name: 'Publisher', stage: 'Publishing',
    responsibility: 'Drafts YouTube metadata and, only after valid final approval, uploads to LYTDesign as private for a separate explicit release.',
    inputs: ['Final video', 'Approved metadata', 'Final approval fingerprint'],
    outputs: ['YouTube metadata draft', 'Private upload (future)'],
    requires: ['ai', 'youtube'], checkpoint: 'final'
  }
];

export function agentStatus(health) {
  const have = {
    ai: !!health.providers.ai.configured,
    tts: !!health.providers.tts.configured,
    youtube: !!health.providers.youtube.configured,
    ffmpeg: !!health.tools.ffmpeg?.found
  };
  return AGENTS.map(a => {
    const missing = a.requires.filter(r => !have[r]);
    return {
      ...a,
      implemented: false,
      prerequisites: a.requires.map(r => ({ id: r, met: have[r] })),
      canRun: false,
      state: 'not-implemented',
      reason: 'Agent runner is not implemented in MediaLYT V1.' + (missing.length ? ` Also missing: ${missing.join(', ')}.` : '')
    };
  });
}
