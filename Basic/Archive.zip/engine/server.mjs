// MediaLYT Media Hub — local production engine (Node.js built-ins only).
// Binds to loopback, serves the MediaLYT interface from the same origin and
// exposes a small JSON API. No provider credentials are read, stored or sent.
import http from 'node:http';
import fs from 'node:fs/promises';
import { createReadStream } from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { openDatabase } from './db.mjs';
import { LIBRARIES, ensureStorage, storeUpload, resolveStored, detectTools, ffprobeFile, storageInfo, extOf } from './media.mjs';
import { CHECKPOINTS, ROLES, approvalState, deriveStatus } from './workflow.mjs';
import { agentStatus } from './agents.mjs';

export const VERSION = '0.1.0';
const HERE = path.dirname(fileURLToPath(import.meta.url));
const PROJECT = path.resolve(HERE, '..');

const httpError = (status, message, extra) => Object.assign(new Error(message), { status, extra });
const LOOPBACK = new Set(['127.0.0.1', '::1', 'localhost']);

export async function createEngine(options = {}) {
  const port = Number(options.port ?? process.env.MEDIALYT_PORT ?? 4717);
  const host = options.host ?? process.env.MEDIALYT_HOST ?? '127.0.0.1';
  if (!LOOPBACK.has(host)) throw new Error(`MediaLYT V1 only binds to loopback (got "${host}").`);
  const dataDir = path.resolve(options.dataDir ?? process.env.MEDIALYT_DATA_DIR ?? path.join(PROJECT, 'data'));
  const appFile = path.resolve(options.appFile ?? path.join(PROJECT, 'app', 'MediaLYT.html'));
  const maxUploadBytes = Number(options.maxUploadBytes ?? process.env.MEDIALYT_MAX_UPLOAD_BYTES ?? 20 * 1024 ** 3);
  const log = options.quiet ? () => {} : (...a) => console.log('[media-hub]', ...a);

  await fs.mkdir(dataDir, { recursive: true });
  await ensureStorage(dataDir);
  const db = openDatabase(path.join(dataDir, 'medialyt.sqlite'));
  const interrupted = db.failInterruptedJobs();
  if (interrupted) db.logEvent(null, 'warn', 'engine.recovered', `${interrupted} job(s) were interrupted by an engine stop and marked failed.`);
  const startedAt = new Date().toISOString();
  let tools = await detectTools();
  const ctx = { db, root: dataDir };

  const providers = () => ({
    ai: { configured: false, note: 'No AI provider adapter is configured in V1.' },
    tts: { configured: false, note: 'Text-to-speech provider not selected. Foundation is provider-independent.' },
    youtube: { configured: false, note: 'YouTube upload integration is intentionally not part of V1.' }
  });

  async function health() {
    let sqliteOk = false;
    try { db.raw.prepare('SELECT 1').get(); sqliteOk = true; } catch {}
    return {
      ok: sqliteOk,
      app: 'MediaLYT Media Hub', version: VERSION, startedAt,
      uptimeSec: Math.round(process.uptime()),
      node: process.version, platform: `${process.platform}-${process.arch}`,
      database: { ok: sqliteOk, engine: 'node:sqlite', schemaVersion: db.schemaVersion() },
      storage: await storageInfo(dataDir),
      tools, providers: providers(),
      limits: { maxUploadBytes }
    };
  }

  // ---------- job worker (real work only) ----------
  const queue = [];
  let working = false;
  function enqueue(job, fn) { queue.push({ job, fn }); drain(); }
  async function drain() {
    if (working) return; working = true;
    while (queue.length) {
      const { job, fn } = queue.shift();
      db.updateJob(job.id, { status: 'running', startedAt: new Date().toISOString() });
      try {
        const message = await fn(p => db.updateJob(job.id, { progress: p }));
        db.updateJob(job.id, { status: 'succeeded', progress: 1, message: message || 'Completed', finishedAt: new Date().toISOString() });
      } catch (err) {
        db.updateJob(job.id, { status: 'failed', error: String(err.message || err).slice(0, 1000), finishedAt: new Date().toISOString() });
        db.logEvent(job.productionId, 'error', 'job.failed', `${job.type} failed: ${String(err.message || err).slice(0, 300)}`, { jobId: job.id });
      }
    }
    working = false;
  }
  function queueProbe(asset) {
    if (!tools.ffprobe.found || !['footage', 'audio', 'renders', 'visual'].includes(asset.category)) return null;
    if (asset.category === 'visual' && !asset.mime.startsWith('video/')) return null;
    const job = db.createJob({ productionId: asset.productionId, assetId: asset.id, type: 'media.probe', agent: null, message: `Inspect ${asset.name}` });
    enqueue(job, async () => {
      const probe = await ffprobeFile(resolveStored(dataDir, asset.storedPath));
      db.setAssetProbe(asset.id, probe);
      return probe.durationSec != null ? `Duration ${probe.durationSec}s` : 'Inspected';
    });
    return job;
  }

  // ---------- helpers ----------
  async function productionView(p) {
    const approvals = await approvalState(ctx, p);
    const jobs = db.listJobs({ productionId: p.id, limit: 50 });
    return { ...p, status: deriveStatus(p, approvals, jobs), approvals, jobs, assets: db.listAssets({ productionId: p.id }) };
  }
  const str = (v, max, field) => {
    if (v === undefined) return undefined;
    if (typeof v !== 'string') throw httpError(400, `${field} must be text.`);
    if (v.length > max) throw httpError(400, `${field} is longer than ${max} characters.`);
    return v;
  };
  function validatePatch(p, body) {
    const patch = {};
    if (body.title !== undefined) { const t = str(body.title, 100, 'Title').trim(); if (!t) throw httpError(400, 'Title is required.'); patch.title = t; }
    if (body.format !== undefined) { if (!['video', 'short'].includes(body.format)) throw httpError(400, 'Format must be "video" or "short".'); patch.format = body.format; }
    if (body.brief !== undefined) {
      if (!body.brief || typeof body.brief !== 'object' || Array.isArray(body.brief)) throw httpError(400, 'Brief must be an object.');
      const b = {};
      for (const k of ['idea', 'product', 'audience', 'concept', 'notes', 'callToAction']) { const v = str(body.brief[k], 20000, `Brief ${k}`); if (v !== undefined) b[k] = v; }
      if (body.brief.targetLengthSec !== undefined && body.brief.targetLengthSec !== null && body.brief.targetLengthSec !== '') {
        const n = Number(body.brief.targetLengthSec);
        if (!Number.isInteger(n) || n < 5 || n > 3600) throw httpError(400, 'Target length must be 5–3600 seconds.');
        b.targetLengthSec = n;
      }
      patch.brief = b;
    }
    for (const [k, max] of [['storyboard', 100000], ['script', 100000], ['captions', 200000]]) { const v = str(body[k], max, k); if (v !== undefined) patch[k] = v; }
    if (body.metadata !== undefined) {
      const m = body.metadata;
      if (!m || typeof m !== 'object' || Array.isArray(m)) throw httpError(400, 'Metadata must be an object.');
      const tags = m.tags === undefined ? [] : m.tags;
      if (!Array.isArray(tags) || tags.some(t => typeof t !== 'string')) throw httpError(400, 'Tags must be a list of text values.');
      const cleanTags = tags.map(t => t.trim()).filter(Boolean);
      if (cleanTags.join(',').length > 500) throw httpError(400, 'Tags exceed YouTube’s 500 character limit.');
      const privacy = m.privacy ?? 'private';
      if (!['private', 'unlisted', 'public'].includes(privacy)) throw httpError(400, 'Privacy must be private, unlisted or public.');
      const publishAt = m.publishAt ?? '';
      if (publishAt && !Number.isFinite(Date.parse(publishAt))) throw httpError(400, 'Schedule must be a valid date and time.');
      const title = str(m.title ?? '', 100, 'YouTube title');
      if (/[<>]/.test(title)) throw httpError(400, 'YouTube titles cannot contain < or >.');
      patch.metadata = {
        title, description: str(m.description ?? '', 5000, 'YouTube description'), tags: cleanTags, privacy, publishAt,
        madeForKids: !!m.madeForKids, syntheticMedia: !!m.syntheticMedia, categoryId: str(m.categoryId ?? '', 8, 'Category') || ''
      };
      if (p.metadata?.youtubeVideoId) patch.metadata.youtubeVideoId = p.metadata.youtubeVideoId;
    }
    if (body.roles !== undefined) {
      if (!body.roles || typeof body.roles !== 'object') throw httpError(400, 'Roles must be an object.');
      const roles = { ...p.roles };
      for (const [role, assetId] of Object.entries(body.roles)) {
        if (!ROLES[role]) throw httpError(400, `Unknown asset role "${role}".`);
        if (assetId === null || assetId === '') { delete roles[role]; continue; }
        const a = db.getAsset(String(assetId));
        if (!a || a.library !== 'media') throw httpError(400, `Asset for ${ROLES[role].label} does not exist.`);
        if (a.category !== ROLES[role].category) throw httpError(400, `${ROLES[role].label} must be a ${LIBRARIES.media[ROLES[role].category].label} file.`);
        if (a.productionId !== p.id) throw httpError(400, 'That asset is not linked to this production.');
        roles[role] = a.id;
      }
      patch.roles = roles;
    }
    if (body.archived !== undefined) patch.archived = !!body.archived;
    return patch;
  }
  async function readJson(req) {
    const type = String(req.headers['content-type'] || '');
    if (!type.includes('application/json')) throw httpError(415, 'Send JSON with Content-Type: application/json.');
    let size = 0; const chunks = [];
    for await (const c of req) { size += c.length; if (size > 1024 * 1024) throw httpError(413, 'Request body too large.'); chunks.push(c); }
    if (!size) return {};
    try { return JSON.parse(Buffer.concat(chunks).toString('utf8')); } catch { throw httpError(400, 'Invalid JSON.'); }
  }
  function send(res, status, body, headers = {}) {
    const data = Buffer.from(JSON.stringify(body));
    res.writeHead(status, { 'Content-Type': 'application/json; charset=utf-8', 'Content-Length': data.length, 'Cache-Control': 'no-store', ...headers });
    res.end(data);
  }
  const needProduction = id => { const p = db.getProduction(id); if (!p) throw httpError(404, 'Production not found.'); return p; };

  async function serveAsset(req, res, asset, download) {
    const abs = resolveStored(dataDir, asset.storedPath);
    let st; try { st = await fs.stat(abs); } catch { throw httpError(404, 'File is missing from storage.'); }
    const base = { 'Content-Type': asset.mime, 'Accept-Ranges': 'bytes', 'Cache-Control': 'no-store', 'X-Content-Type-Options': 'nosniff',
      'Content-Disposition': `${download ? 'attachment' : 'inline'}; filename*=UTF-8''${encodeURIComponent(asset.name)}` };
    if (asset.mime === 'image/svg+xml') base['Content-Security-Policy'] = "default-src 'none'; style-src 'unsafe-inline'; sandbox";
    const range = /^bytes=(\d*)-(\d*)$/.exec(String(req.headers.range || ''));
    if (range && (range[1] || range[2])) {
      let start = range[1] ? Number(range[1]) : st.size - Number(range[2]);
      let end = range[1] && range[2] ? Number(range[2]) : st.size - 1;
      if (start < 0) start = 0;
      if (start >= st.size || end < start) { res.writeHead(416, { 'Content-Range': `bytes */${st.size}` }); return res.end(); }
      end = Math.min(end, st.size - 1);
      res.writeHead(206, { ...base, 'Content-Range': `bytes ${start}-${end}/${st.size}`, 'Content-Length': end - start + 1 });
      return createReadStream(abs, { start, end }).pipe(res);
    }
    res.writeHead(200, { ...base, 'Content-Length': st.size });
    createReadStream(abs).pipe(res);
  }

  // ---------- routes ----------
  const routes = [];
  const route = (method, pattern, fn) => routes.push({ method, re: new RegExp('^' + pattern.replace(/:(\w+)/g, '(?<$1>[^/]+)') + '$'), fn });

  route('GET', '/api/health', async () => [200, await health()]);
  route('POST', '/api/tools/recheck', async () => { tools = await detectTools(); return [200, tools]; });
  route('GET', '/api/agents', async () => [200, { agents: agentStatus(await health()) }]);
  route('POST', '/api/productions/:id/agents/:agent/run', async ({ params }) => {
    needProduction(params.id);
    throw httpError(501, 'Agent execution is not implemented in MediaLYT V1. No job was created.');
  });
  route('GET', '/api/library', async () => [200, { libraries: LIBRARIES, counts: db.countAssets(), roles: ROLES, checkpoints: CHECKPOINTS }]);

  route('GET', '/api/overview', async () => {
    const prods = await Promise.all(db.listProductions().map(productionView));
    const byStatus = Object.fromEntries(['draft', 'producing', 'review', 'approved', 'published', 'failed'].map(s => [s, 0]));
    prods.forEach(p => byStatus[p.status]++);
    const pending = [];
    for (const p of prods) for (const cp of CHECKPOINTS) {
      const a = p.approvals[cp.id];
      // Only checkpoints that can actually be reviewed now (requirements complete, not yet validly approved).
      if (a.ready && !a.valid) pending.push({ productionId: p.id, title: p.title, checkpoint: cp.id, label: cp.label, state: a.state });
    }
    const renders = db.listAssets({ library: 'media', category: 'renders' }).slice(0, 8);
    const activeJobs = db.listJobs({ status: 'running' }).concat(db.listJobs({ status: 'queued' }));
    return [200, { total: prods.length, byStatus, pending, recentRenders: renders, activeJobs, recentJobs: db.listJobs({ limit: 8 }), recentEvents: db.listEvents({ limit: 12 }) }];
  });

  route('GET', '/api/productions', async ({ url }) => {
    const list = db.listProductions({ includeArchived: url.searchParams.get('archived') === '1' });
    return [200, { productions: await Promise.all(list.map(async p => { const v = await productionView(p); return { id: v.id, title: v.title, format: v.format, status: v.status, archived: v.archived, createdAt: v.createdAt, updatedAt: v.updatedAt, assetCount: v.assets.length, approvals: Object.fromEntries(Object.entries(v.approvals).map(([k, a]) => [k, a.state])) }; })) }];
  });
  route('POST', '/api/productions', async ({ req }) => {
    const body = await readJson(req);
    const title = str(body.title ?? '', 100, 'Title').trim();
    if (!title) throw httpError(400, 'Title is required.');
    const format = body.format ?? 'video';
    if (!['video', 'short'].includes(format)) throw httpError(400, 'Format must be "video" or "short".');
    let p = db.createProduction({ title, format });
    if (body.brief) p = db.updateProduction(p.id, validatePatch(p, { brief: body.brief }));
    db.logEvent(p.id, 'info', 'production.created', `Production “${title}” created (${format === 'short' ? 'Short' : 'Video'}).`);
    return [201, await productionView(p)];
  });
  route('GET', '/api/productions/:id', async ({ params }) => [200, await productionView(needProduction(params.id))]);
  route('PATCH', '/api/productions/:id', async ({ req, params }) => {
    const p = needProduction(params.id);
    const patch = validatePatch(p, await readJson(req));
    if (!Object.keys(patch).length) throw httpError(400, 'Nothing to update.');
    const before = await approvalState(ctx, p);
    const next = db.updateProduction(p.id, patch);
    const after = await approvalState(ctx, next);
    db.logEvent(p.id, 'info', 'production.updated', `Updated ${Object.keys(patch).join(', ')}.`);
    for (const cp of CHECKPOINTS) if (before[cp.id].valid && !after[cp.id].valid)
      db.logEvent(p.id, 'warn', 'approval.invalidated', `${cp.label} is no longer valid because approved content changed.`);
    return [200, await productionView(next)];
  });
  route('DELETE', '/api/productions/:id', async ({ params }) => {
    const p = needProduction(params.id);
    db.deleteProduction(p.id);
    db.logEvent(null, 'warn', 'production.deleted', `Production “${p.title}” deleted. Linked media files were kept in the Media Library.`);
    return [200, { deleted: true }];
  });
  route('POST', '/api/productions/:id/approvals/:checkpoint', async ({ req, params }) => {
    const p = needProduction(params.id);
    const cp = CHECKPOINTS.find(c => c.id === params.checkpoint);
    if (!cp) throw httpError(404, 'Unknown checkpoint.');
    const body = await readJson(req);
    const state = (await approvalState(ctx, p))[cp.id];
    if (!state.ready) throw httpError(409, `${cp.label} is not ready: ${state.requirements.filter(r => !r.ok).map(r => r.reason).join('; ')}.`);
    if (body.fingerprint !== state.fingerprint) throw httpError(409, 'The content changed after you reviewed it. Reload and review again before approving.', { currentFingerprint: state.fingerprint });
    db.setApproval(p.id, cp.id, state.fingerprint, str(body.note ?? '', 2000, 'Note'));
    db.logEvent(p.id, 'info', 'approval.granted', `${cp.label} granted.`, { fingerprint: state.fingerprint });
    return [200, await productionView(p)];
  });
  route('DELETE', '/api/productions/:id/approvals/:checkpoint', async ({ req, params }) => {
    const p = needProduction(params.id);
    const cp = CHECKPOINTS.find(c => c.id === params.checkpoint);
    if (!cp) throw httpError(404, 'Unknown checkpoint.');
    const body = await readJson(req);
    const reason = str(body.reason ?? '', 2000, 'Reason').trim();
    const removed = db.clearApproval(p.id, cp.id);
    db.logEvent(p.id, 'warn', 'approval.changes-requested', `${cp.label}: changes requested${reason ? ' — ' + reason : ''}.`, { hadApproval: removed });
    return [200, await productionView(p)];
  });
  route('GET', '/api/productions/:id/events', async ({ params, url }) => { needProduction(params.id); return [200, { events: db.listEvents({ productionId: params.id, limit: url.searchParams.get('limit') }) }]; });
  route('GET', '/api/events', async ({ url }) => [200, { events: db.listEvents({ limit: url.searchParams.get('limit') }) }]);
  route('GET', '/api/jobs', async ({ url }) => [200, { jobs: db.listJobs({ productionId: url.searchParams.get('productionId') || undefined, status: url.searchParams.get('status') || undefined, limit: url.searchParams.get('limit') }) }]);
  route('GET', '/api/jobs/:id', async ({ params }) => { const j = db.getJob(params.id); if (!j) throw httpError(404, 'Job not found.'); return [200, j]; });

  route('GET', '/api/assets', async ({ url }) => [200, { assets: db.listAssets({ library: url.searchParams.get('library') || undefined, category: url.searchParams.get('category') || undefined, productionId: url.searchParams.get('productionId') || undefined }) }]);
  route('POST', '/api/assets', async ({ req, url }) => {
    const library = url.searchParams.get('library') || 'media';
    const category = url.searchParams.get('category') || '';
    const name = url.searchParams.get('name') || '';
    const productionId = url.searchParams.get('productionId') || null;
    const def = LIBRARIES[library]?.[category];
    if (!def) throw httpError(400, 'Unknown library or category.');
    if (!name) throw httpError(400, 'File name is required.');
    if (!def.ext.includes(extOf(name))) throw httpError(415, `${def.label} accepts: ${def.ext.join(', ')}.`);
    if (productionId) { if (library !== 'media') throw httpError(400, 'Only Media Library files can be linked to a production.'); needProduction(productionId); }
    const declared = Number(req.headers['content-length'] || 0);
    if (declared > maxUploadBytes) throw httpError(413, `Upload exceeds the ${maxUploadBytes} byte limit.`);
    const stored = await storeUpload(dataDir, { library, category, name, source: req, maxBytes: maxUploadBytes });
    const asset = db.insertAsset({ ...stored, library, category, productionId, name });
    db.logEvent(productionId, 'info', 'asset.added', `${def.label}: ${name} added (${stored.size} bytes).`, { assetId: asset.id, sha256: stored.sha256 });
    const job = queueProbe(asset);
    return [201, { asset, probeJob: job }];
  });
  route('GET', '/api/assets/:id', async ({ params }) => { const a = db.getAsset(params.id); if (!a) throw httpError(404, 'Asset not found.'); return [200, a]; });
  route('PATCH', '/api/assets/:id', async ({ req, params }) => {
    const a = db.getAsset(params.id); if (!a) throw httpError(404, 'Asset not found.');
    const body = await readJson(req);
    if (!('productionId' in body)) throw httpError(400, 'Only productionId can be changed.');
    if (a.library !== 'media') throw httpError(400, 'Only Media Library files can be linked to a production.');
    const pid = body.productionId || null;
    if (pid) needProduction(pid);
    db.raw.prepare('UPDATE assets SET production_id=? WHERE id=?').run(pid, a.id);
    db.logEvent(pid || a.productionId, 'info', 'asset.linked', `${a.name} ${pid ? 'linked to' : 'unlinked from'} production.`);
    return [200, db.getAsset(a.id)];
  });
  route('DELETE', '/api/assets/:id', async ({ params }) => {
    const a = db.getAsset(params.id); if (!a) throw httpError(404, 'Asset not found.');
    for (const p of db.listProductions({ includeArchived: true })) {
      const used = Object.entries(p.roles || {}).filter(([, id]) => id === a.id).map(([r]) => ROLES[r]?.label || r);
      if (used.length) throw httpError(409, `This file is selected as ${used.join(', ')} in “${p.title}”. Deselect it there first.`);
    }
    db.deleteAsset(a.id);
    await fs.rm(resolveStored(dataDir, a.storedPath), { force: true });
    db.logEvent(a.productionId, 'warn', 'asset.deleted', `${a.name} deleted from storage.`);
    return [200, { deleted: true }];
  });

  route('GET', '/api/brand/notes', async () => [200, { notes: db.listBrandNotes() }]);
  const noteBody = b => {
    if (!['product', 'template', 'guideline'].includes(b.kind)) throw httpError(400, 'Kind must be product, template or guideline.');
    const title = str(b.title ?? '', 120, 'Title').trim(); if (!title) throw httpError(400, 'Title is required.');
    return { kind: b.kind, title, body: str(b.body ?? '', 50000, 'Body') };
  };
  route('POST', '/api/brand/notes', async ({ req }) => { const n = db.createBrandNote(noteBody(await readJson(req))); db.logEvent(null, 'info', 'brand.note', `Brand entry “${n.title}” created.`); return [201, n]; });
  route('PATCH', '/api/brand/notes/:id', async ({ req, params }) => { const n = db.updateBrandNote(params.id, noteBody(await readJson(req))); if (!n) throw httpError(404, 'Entry not found.'); return [200, n]; });
  route('DELETE', '/api/brand/notes/:id', async ({ params }) => { if (!db.deleteBrandNote(params.id)) throw httpError(404, 'Entry not found.'); return [200, { deleted: true }]; });

  // ---------- server ----------
  const allowedHosts = () => new Set([`127.0.0.1:${server.address().port}`, `localhost:${server.address().port}`, `[::1]:${server.address().port}`]);
  const server = http.createServer(async (req, res) => {
    const url = new URL(req.url, 'http://local');
    try {
      // Host check blocks DNS-rebinding; Origin + custom header blocks cross-site writes.
      if (!allowedHosts().has(String(req.headers.host || ''))) throw httpError(421, 'Unrecognised Host header.');
      if (!['GET', 'HEAD'].includes(req.method)) {
        const origin = req.headers.origin;
        if (origin && !allowedHosts().has(origin.replace(/^http:\/\//, ''))) throw httpError(403, 'Cross-origin request refused.');
        if (req.headers['x-medialyt'] !== '1') throw httpError(403, 'Missing X-MediaLYT request header.');
      }
      if (req.method === 'GET' && (url.pathname === '/' || url.pathname === '/index.html' || url.pathname === '/MediaLYT.html')) {
        const html = await fs.readFile(appFile);
        res.writeHead(200, {
          'Content-Type': 'text/html; charset=utf-8', 'Cache-Control': 'no-store', 'X-Content-Type-Options': 'nosniff', 'Referrer-Policy': 'no-referrer',
          'Content-Security-Policy': "default-src 'self'; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline' https://fonts.googleapis.com https://cdn.jsdelivr.net; font-src 'self' data: https://fonts.gstatic.com https://cdn.jsdelivr.net; img-src 'self' data: blob:; media-src 'self' blob:; connect-src 'self'; frame-ancestors 'none'; base-uri 'none'; form-action 'none'; object-src 'none'"
        });
        return res.end(html);
      }
      const m = /^\/api\/assets\/([^/]+)\/(content|download)$/.exec(url.pathname);
      if (m && req.method === 'GET') { const a = db.getAsset(m[1]); if (!a) throw httpError(404, 'Asset not found.'); return await serveAsset(req, res, a, m[2] === 'download'); }
      for (const r of routes) {
        if (r.method !== req.method) continue;
        const match = r.re.exec(url.pathname);
        if (!match) continue;
        const params = Object.fromEntries(Object.entries(match.groups || {}).map(([k, v]) => [k, decodeURIComponent(v)]));
        const [status, body] = await r.fn({ req, res, url, params });
        return send(res, status, body);
      }
      throw httpError(404, 'Not found.');
    } catch (err) {
      const status = err.status || 500;
      if (status >= 500) { log('error', req.method, url.pathname, err); db.logEvent(null, 'error', 'engine.error', `${req.method} ${url.pathname}: ${String(err.message).slice(0, 300)}`); }
      if (!res.headersSent) send(res, status, { error: status >= 500 && !err.status ? 'Internal engine error. See the engine log.' : err.message, ...(err.extra || {}) });
      else res.destroy();
    }
  });
  server.requestTimeout = 0; // large uploads
  await new Promise((resolve, reject) => { server.once('error', reject); server.listen(port, host, resolve); });
  log(`MediaLYT Media Hub ${VERSION} listening on http://${host === '::1' ? '[::1]' : host}:${server.address().port}/`);
  log(`data: ${dataDir}`);
  log(`ffmpeg: ${tools.ffmpeg.found ? tools.ffmpeg.version : 'not found'} · ffprobe: ${tools.ffprobe.found ? tools.ffprobe.version : 'not found'}`);
  return {
    server, db, dataDir, port: server.address().port,
    close: () => new Promise(r => server.close(() => { db.close(); r(); }))
  };
}

if (process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  createEngine().catch(err => { console.error('[media-hub] failed to start:', err.message); process.exit(1); });
}
