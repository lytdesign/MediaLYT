// MediaLYT Media Hub — approval checkpoints, fingerprints and derived production status.
// An approval stores the fingerprint of exactly what was approved. Whenever the
// current fingerprint differs (text edited, file replaced or modified on disk),
// the approval is reported as invalid and later checkpoints are blocked.
import { createHash } from 'node:crypto';
import { currentFileHash } from './media.mjs';

export const CHECKPOINTS = [
  { id: 'creative', label: 'Creative approval', covers: 'Concept, storyboard and script' },
  { id: 'production', label: 'Production approval', covers: 'Narration, preview edit and thumbnail' },
  { id: 'final', label: 'Final publishing approval', covers: 'Exact final video file and publishing metadata' }
];

// Production asset roles a person (or a future agent) assigns from real stored assets.
export const ROLES = {
  narration: { category: 'audio', label: 'Narration audio' },
  preview: { category: 'renders', label: 'Preview render' },
  thumbnail: { category: 'thumbnails', label: 'Selected thumbnail' },
  final: { category: 'renders', label: 'Final video' },
  captions: { category: 'captions', label: 'Caption file' }
};

const canon = v => JSON.stringify(v, Object.keys(flatKeys(v)).sort());
function flatKeys(v, acc = {}) { if (v && typeof v === 'object') for (const k of Object.keys(v)) { acc[k] = 1; flatKeys(v[k], acc); } return acc; }
const sha = s => createHash('sha256').update(s).digest('hex');

const textOk = s => typeof s === 'string' && s.trim().length > 0;

async function roleFile(ctx, p, role) {
  const id = p.roles?.[role];
  if (!id) return { ok: false, reason: `${ROLES[role].label} not selected` };
  const asset = ctx.db.getAsset(id);
  if (!asset) return { ok: false, reason: `${ROLES[role].label} asset no longer exists` };
  const hash = await currentFileHash(ctx.root, asset.storedPath);
  if (!hash) return { ok: false, reason: `${ROLES[role].label} file is missing from storage` };
  return { ok: true, asset, hash, changedOnDisk: hash !== asset.sha256 };
}

// Returns {requirements:[{label,ok,reason}], fingerprint|null}
async function evaluate(ctx, p, checkpoint, prior) {
  const req = [];
  const add = (label, ok, reason) => req.push({ label, ok: !!ok, reason: ok ? '' : reason });
  if (checkpoint === 'creative') {
    add('Concept in brief', textOk(p.brief?.concept), 'Write the video concept in the brief');
    add('Storyboard', textOk(p.storyboard), 'Storyboard is empty');
    add('Script', textOk(p.script), 'Script is empty');
    const ok = req.every(r => r.ok);
    return { requirements: req, fingerprint: ok ? sha(canon({ v: 1, brief: p.brief || {}, storyboard: p.storyboard, script: p.script, format: p.format })) : null };
  }
  if (checkpoint === 'production') {
    add('Creative approval valid', prior.creative?.valid, 'Creative approval is missing or no longer valid');
    const parts = {};
    for (const role of ['narration', 'preview', 'thumbnail']) {
      const f = await roleFile(ctx, p, role);
      add(ROLES[role].label, f.ok, f.reason);
      if (f.ok) parts[role] = f.hash;
    }
    const ok = req.every(r => r.ok);
    return { requirements: req, fingerprint: ok ? sha(canon({ v: 1, creative: prior.creative.fingerprint, parts })) : null };
  }
  if (checkpoint === 'final') {
    add('Production approval valid', prior.production?.valid, 'Production approval is missing or no longer valid');
    const f = await roleFile(ctx, p, 'final');
    add(ROLES.final.label, f.ok, f.reason);
    add('Publishing title', textOk(p.metadata?.title), 'Add a YouTube title in Publishing');
    add('Publishing description', textOk(p.metadata?.description), 'Add a YouTube description in Publishing');
    const ok = req.every(r => r.ok);
    const meta = p.metadata || {};
    return { requirements: req, fingerprint: ok ? sha(canon({ v: 1, production: prior.production.fingerprint, final: f.hash, metadata: { title: meta.title || '', description: meta.description || '', tags: meta.tags || [], privacy: meta.privacy || 'private', publishAt: meta.publishAt || '', madeForKids: !!meta.madeForKids, syntheticMedia: !!meta.syntheticMedia, format: p.format } })) : null };
  }
  throw new Error('Unknown checkpoint');
}

export async function approvalState(ctx, p) {
  const stored = Object.fromEntries(ctx.db.getApprovals(p.id).map(a => [a.checkpoint, a]));
  const out = {};
  for (const cp of CHECKPOINTS) {
    const ev = await evaluate(ctx, p, cp.id, out);
    const rec = stored[cp.id] || null;
    const valid = !!(rec && ev.fingerprint && rec.fingerprint === ev.fingerprint);
    out[cp.id] = {
      ...cp,
      requirements: ev.requirements,
      ready: !!ev.fingerprint,
      fingerprint: ev.fingerprint,
      approved: !!rec,
      approvedAt: rec?.approvedAt || null,
      approvedFingerprint: rec?.fingerprint || null,
      note: rec?.note || '',
      valid,
      state: valid ? 'approved' : rec ? 'invalidated' : ev.fingerprint ? 'ready' : 'incomplete'
    };
  }
  return out;
}

// Status is derived from real records only; nothing is set to "approved" or
// "published" without the corresponding evidence.
export function deriveStatus(p, approvals, jobs) {
  if (p.metadata?.youtubeVideoId) return 'published';
  // `jobs` are this production's jobs, newest first. Media probes are housekeeping.
  const stageJobs = jobs.filter(j => j.type !== 'media.probe');
  if (stageJobs.some(j => j.status === 'queued' || j.status === 'running')) return 'producing';
  if (stageJobs[0]?.status === 'failed') return 'failed';
  if (approvals.final.valid) return 'approved';
  // Something can be reviewed right now (new, or changed since it was approved).
  if (Object.values(approvals).some(a => a.ready && !a.valid)) return 'review';
  // Concept and script approved: production work (voice, edit, thumbnail) is under way.
  if (approvals.creative.valid) return 'producing';
  return 'draft';
}
